from MultAddRipetute import add_ripetute;
import math
def mult_sums(X,Y):
    risultato = 0
    cifre = int(math.log10(Y))+1 # numero di cifre di Y

    def ennesima_cifra(numero, n):
        return numero // 10**n % 10
    
    for i in range(cifre):
        y = ennesima_cifra(Y,i)
        r = add_ripetute(X,y)
        risultato += (r * pow(10,i)) 
    
    return risultato

if __name__ == "__main__":
    print(mult_sums(4,4))
    print(mult_sums(10,10))
    print(mult_sums(100,100))