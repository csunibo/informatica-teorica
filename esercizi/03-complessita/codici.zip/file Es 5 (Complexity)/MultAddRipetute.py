def add_ripetute(X,Y):
    risultato = 0
    for i in range(Y):
        risultato += X
    return risultato

if __name__ == "__main__":
    O = ((9*pow(10,9)) / 86.4 * pow(10,3) * pow(10,3)) / 365
