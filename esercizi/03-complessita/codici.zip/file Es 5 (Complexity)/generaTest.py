import random
import math

NUMERO_INSIEMI_DEFAULT = 100
NUMERO_ELEMENTI_DEFAULT = 1000
def get_numero_max_elementi_per_insieme(numero_elementi):
    return math.floor(math.log(numero_elementi))

def genera_insiemi(numero_insiemi = NUMERO_INSIEMI_DEFAULT, 
                   numero_elementi = NUMERO_ELEMENTI_DEFAULT, 
                   get_numero_max_elementi_per_insieme=get_numero_max_elementi_per_insieme):
    insiemi = []
    numero_max_elementi_per_insieme = get_numero_max_elementi_per_insieme(numero_elementi)
    print(f"numero max elementi per insieme : {numero_max_elementi_per_insieme}")
    for i in range(numero_insiemi):
        CARDINALITA_INSIEME = random.randint(1,numero_max_elementi_per_insieme)
        insieme = set()
        for e in range(CARDINALITA_INSIEME):
            insieme.add(random.choice(range(numero_elementi)))
        insiemi.append(insieme)
    return insiemi

if __name__ == "__main__":
    print(genera_insiemi())

