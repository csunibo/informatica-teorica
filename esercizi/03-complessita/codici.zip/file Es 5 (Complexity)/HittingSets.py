from pysat.examples.hitman import Hitman
from generaTest import genera_insiemi
import math
def funzioneLog10(numero_elementi):
	return int(math.log10(numero_elementi))
		
sets = genera_insiemi(
	numero_insiemi=pow(10,3),
	numero_elementi=pow(10,5),
	get_numero_max_elementi_per_insieme=funzioneLog10)
	
print("Inizia test...")
h = Hitman(bootstrap_with=sets, solver='m22', htype='lbx')
hittingSet = h.get()
print(f"hittingSet: {hittingSet}")
print(f"numero elementi: {len(hittingSet)}")