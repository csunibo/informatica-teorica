from pysat.examples.hitman import Hitman
h = Hitman(solver='m22', htype='lbx')

# adding sets to hit

h.hit([1, 2, 3])
h.hit([1, 4])
h.hit([5, 6, 7])
#h.hit([6, 7, 8])
#h.hit([9, 10])
print(h.get())
h.block([1, 5])
print(h.get())
h.delete()