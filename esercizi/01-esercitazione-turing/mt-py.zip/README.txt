## Usage
The interpreter reads a JSON file as instruction and process the input.

From terminal:

python turingmachine.py --instructions sum.json --input " 11*111" -r -s .01
python turingmachine.py --instructions multiplication.json --input "11 111" -r -s .01


python turingmachine.py --help

usage: turingmachine.py [-h] [-b INITIAL] [-e END] [-s SPEED] [-r] [-a] -i
                        INSTRUCTIONS -t INPUT

Implementation of a universal Turing Machine.

options:
  -h, --help            show this help message and exit
  -b INITIAL, --initial INITIAL
                        Initial state to begin
  -e END, --end END     End state
  -s SPEED, --speed SPEED
                        Rendering speed in seconds
  -r, --render          Render turing machine
  -a, --interactive     Interactive mode, speed will be useless when using
                        this parameter

required arguments:
  -i INSTRUCTIONS, --instructions INSTRUCTIONS
                        Instructions, as JSON file
  -t INPUT, --input INPUT
                        Input tape
